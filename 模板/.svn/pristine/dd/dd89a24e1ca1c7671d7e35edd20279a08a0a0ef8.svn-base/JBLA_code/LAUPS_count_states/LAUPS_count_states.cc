#include <iostream>

#include <jellyfish/mer_dna.hpp>
#include <jellyfish/thread_exec.hpp>
#include <jellyfish/hash_counter.hpp>
#include <jellyfish/stream_manager.hpp>
#include <jellyfish/mer_overlap_sequence_parser.hpp>
#include <jellyfish/mer_iterator.hpp>
#include <jellyfish/err.hpp>
#include <jellyfish/jellyfish.hpp>
#include <jellyfish/large_hash_array.hpp>

typedef jellyfish::cooperative::hash_counter<jellyfish::mer_dna> mer_hash_type;
typedef jellyfish::mer_overlap_sequence_parser<jellyfish::stream_manager<char**>> sequence_parser_type;
typedef jellyfish::mer_iterator<sequence_parser_type, jellyfish::mer_dna> mer_iterator_type;
namespace err = jellyfish::err;

using jellyfish::mer_dna;

//xman:Given a file, the KMER in the different K values in the file is calculated, 
//and the LAUPs of different K and the GC AG content of LAUP are calculated.

//xman:Input: 
//1.the PATH of the file 
//2.start K
//3.end K 
//4.and the file number index

std::string arr[] = { "A", "T", "C", "G" };

int arr_size = 4;

std::string fromIntToStr(long i);
std::string toString(long i);
uint64_t getValueByKey(mer_dna m);

class mer_counter: public jellyfish::thread_exec {
	mer_hash_type& mer_hash_;
	jellyfish::stream_manager<char**> streams_;
	sequence_parser_type parser_;
	const bool canonical_;

public:
	mer_counter(int nb_threads, mer_hash_type& mer_hash, char** file_begin,
			char** file_end, bool canonical) :
			mer_hash_(mer_hash), streams_(file_begin, file_end), parser_(
					jellyfish::mer_dna::k(), streams_.nb_streams(),
					3 * nb_threads, 4096, streams_), canonical_(canonical) {
	}

	virtual void start(int thid) {
		mer_iterator_type mers(parser_, canonical_);

		for (; mers; ++mers)
			mer_hash_.add(*mers, 1);
		mer_hash_.done();
	}
};

std::string fromIntToStr(long i) {
	std::string result = "";
	for (int j = 0; j < mer_dna::k(); j++) {
		result += arr[((long) (i / pow(arr_size, j))) % arr_size];
	}

	return result;
}

std::string toString(long i){
	char str[20];
	sprintf(str,"%d",i);

	return str;
}

std::string doubleToString(double i){
	char str[20];
	sprintf(str,"%1.10lf",i);

	return str;
}

int main(int argc, char *argv[]) {
	// Parameters that are hard coded. Most likely some of those should
	// be switches to this program.
	const uint64_t hash_size_max = 2000000000;
	const uint64_t hash_size_min = 500000;
	uint64_t hash_size = 0;
	const uint32_t counter_len_max = 50;  // Minimum length of counting field
	const uint32_t counter_len_min = 5;  // Minimum length of counting field
	uint64_t counter_len = 0;

	const uint32_t num_reprobes = 126;
	const uint32_t num_threads = 32; // Number of concurrent threads
	const bool canonical = false; // Use canonical representation

	uint32_t k_num = 0;

	uint32_t k_min = 1;
	uint32_t k_max = 30;
	
	uint32_t k_from = 0;
	sscanf(argv[2], "%d", &k_from);
	uint32_t k_to = 0;
	sscanf(argv[3], "%d", &k_to);
	
	uint32_t kind = 0;
	sscanf(argv[4], "%d", &kind);
	
	std::string file_path = argv[1];
		
	char *file_a = const_cast<char*>(file_path.data());
	char *file_a_end = "";
	
	char *file_start[3];
	file_start[0] = file_a;
	file_start[1] = file_a_end;
	
	//xman:output path
	std::string outpath = "/home/jellyfish/LAUPS_count_states/"+toString(kind)+"result.out";
	
	std::string LAUP_num_str = "";
	std::string LAUP_GC_str = "";
	std::string LAUP_AG_str = "";
	
	for(k_num=k_from; k_num<=k_to; k_num++)
	{
		jellyfish::mer_dna::k(k_num); // Set length of mers
		
		std::string outpath_LAUP = "/home/jellyfish/LAUPS_count_states/"+toString(kind)+"_"+toString(k_num)+"LAUP.out";
		
		std::ofstream outfile_LAUP(outpath_LAUP);
		if(!outfile_LAUP){  
			std::cerr<<"open error!";  
			exit(1);  
		}
	
		hash_size = hash_size_min
					+ k_num*(hash_size_max - hash_size_min) / (k_max - k_min + 1);
		counter_len = counter_len_max
					- k_num * (counter_len_max - counter_len_min + 1)
							/ (k_max - k_min + 1);

		mer_hash_type mer_hash_a(hash_size, jellyfish::mer_dna::k() * 2,
				counter_len, num_threads, num_reprobes);

		// count the kmers
		mer_counter counter_a(num_threads, mer_hash_a, file_start, file_start + 1,
				canonical);
		counter_a.exec_join(num_threads);

		const auto jf_ary_a = mer_hash_a.ary();
		
		uint32_t LAUP_num = 0;
		uint32_t GC_all = 0;
		uint32_t GA_all = 0;
		
		//xman:LAUPs count
		for (long i = 0; i < pow(arr_size, mer_dna::k()); i++) {
			//xman��Enumerate all possible permutations
			std::string str_every = fromIntToStr(i);
			mer_dna m;
			try {
					m = str_every;
					if (canonical)
						m.canonicalize();

					//xman:find it in k-mer
					uint64_t val = 0;
					uint64_t k_num_a = jf_ary_a->get_val_for_key(m, &val);

					if (k_num_a <= 0) {

						//xman:not found it is LAUP
						LAUP_num++;
						
						outfile_LAUP << ">"+ toString(LAUP_num) +"\n";
						outfile_LAUP << str_every+"\n";
						
						for (int i = 0; i < mer_dna::k(); i++) {
						
							if (str_every.substr(i, 1) == "C"
									|| str_every.substr(i, 1) == "G") {
								GC_all++;
							}
							
							if (str_every.substr(i, 1) == "A"
									|| str_every.substr(i, 1) == "G") {
								GA_all++;
							}
						}
					}
				}
			 catch (std::length_error e) {
				std::cerr << "Invalid mer '" << m << "'\n";
			}
		}
		
		if(LAUP_num == 0)
		{
			LAUP_num_str +=  "0,";
			LAUP_GC_str += "0,";
			LAUP_AG_str += "0,";
		}
		else
		{
			double gc_rate = (double)GC_all/(LAUP_num * mer_dna::k());
			double ga_rate = (double)GA_all/(LAUP_num * mer_dna::k());
			
			LAUP_num_str +=  toString(LAUP_num) + ",";
			LAUP_GC_str += doubleToString(gc_rate) + ",";
			LAUP_AG_str += doubleToString(ga_rate) + ",";
		}
	}
	
	std::ofstream outfile(outpath);
		if(!outfile){  
			std::cerr<<"open error!";  
			exit(1);  
		}

	outfile << "file:" << file_path
		<< "\n"
		<< "LAUP number from "
		<< k_from
		<< " to "
		<< k_to
		<<":\n" 
		<< LAUP_num_str
		<< "\n"
		<< "CG rate:: " << LAUP_GC_str
		<< "\n"
		<< "AG rate:: " << LAUP_AG_str;
	
	outfile.close();
	
	return 0;
}
